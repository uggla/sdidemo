<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_58ef962a87e6fbbea6027c17a954a18d'] = 'Enregistrement vide renvoyé.';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_f5c493141bb4b2508c5938fd9353291a'] = 'Affichage de %1$s de %2$s';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_49ee3087348e8d44e1feda1917443987'] = 'Nom';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_2a0440eec72540c5b30d9199c01f348c'] = 'Quantité vendue';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_ea067eb37801c5aab1a1c685eb97d601'] = 'Total payé';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_72fd9b5482201824daae557360d91196'] = 'Meilleurs fabricants';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_891374571b52a78a29a622308f1fa292'] = 'Ajoute une liste des meilleurs fabricants dans le tableau de bord des statistiques.';
$_MODULE['<{statsbestmanufacturers}prestashop>statsbestmanufacturers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';


return $_MODULE;
