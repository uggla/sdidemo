<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{dashtrends}prestashop>dashtrends_ee653ade5f520037ef95e9dc2a42364c'] = 'Dashboard Trends';
$_MODULE['<{dashtrends}prestashop>dashtrends_f2d0efa68eb71bfd5209abeb9f4b0943'] = 'Adds a block with a graphical representation of the development of your store(s) based on selected key data.';
$_MODULE['<{dashtrends}prestashop>dashtrends_2d125dc25b158f28a1960bd96a9fa8d1'] = '%s points';
$_MODULE['<{dashtrends}prestashop>dashtrends_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sales';
$_MODULE['<{dashtrends}prestashop>dashtrends_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Orders';
$_MODULE['<{dashtrends}prestashop>dashtrends_8c804960da61b637c548c951652b0cac'] = 'Average Cart Value';
$_MODULE['<{dashtrends}prestashop>dashtrends_d7e637a6e9ff116de2fa89551240a94d'] = 'Visits';
$_MODULE['<{dashtrends}prestashop>dashtrends_e4c3da18c66c0147144767efeb59198f'] = 'Conversion Rate';
$_MODULE['<{dashtrends}prestashop>dashtrends_43d729c7b81bfa5fc10e756660d877d1'] = 'Net Profit';
$_MODULE['<{dashtrends}prestashop>dashtrends_46418a037045b91e6715c4da91a2a269'] = '%s (previous period)';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_2938c7f7e560ed972f8a4f68e80ff834'] = 'Dashboard';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_f1206f9fadc5ce41694f69129aecac26'] = 'Configure';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_63a6a88c066880c5ac42394a22803ca6'] = 'Refresh';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_e537825dd409a90ef70d8c2eb56122a1'] = 'Sum of revenue (excl. tax) generated within the date range by orders considered validated.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_11ff9f68afb6b8b5b8eda218d7c83a65'] = 'Sales';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_8bc1c5ca521b99b87908db0bcd33ec76'] = 'Total number of orders received within the date range that are considered validated.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_7442e29d7d53e549b78d93c46b8cdcfc'] = 'Orders';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_f15f2a2bf99d3dcad2cba1a2c615b9dc'] = 'Average Cart Value is a metric representing the value of an average order within the date range. It is calculated by dividing Sales by Orders.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_791d6355d34dfaf60d68ef04d1ee5767'] = 'Cart Value';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_4f631447981c5fa240006a5ae2c4b267'] = 'Total number of visits within the date range. A visit is the period of time a user is actively engaged with your website.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_d7e637a6e9ff116de2fa89551240a94d'] = 'Visits';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_7a6e858f8c7c0b78fb4d43cefcb8c017'] = 'Ecommerce Conversion Rate is the percentage of visits that resulted in an validated order.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_e4c3da18c66c0147144767efeb59198f'] = 'Conversion Rate';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_8dedc1b3ee3a92212fb5b5acad7f207f'] = 'Net profit is a measure of the profitability of a venture after accounting for all Ecommerce costs. You can provide these costs by clicking on the configuration icon right above here.';
$_MODULE['<{dashtrends}prestashop>dashboard_zone_two_43d729c7b81bfa5fc10e756660d877d1'] = 'Net Profit';


return $_MODULE;
