<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_4f29d8c727dcf2022ac241cb96c31083'] = 'Aucun résultat renvoyé';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_f5c493141bb4b2508c5938fd9353291a'] = 'Affichage de %1$s de %2$s';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_77587239bf4c54ea493c7033e1dbf636'] = 'Nom';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_bc910f8bdf70f29374f496f05be0330c'] = 'Prénom';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_ce8ae9da5b7cd6c3df2929543a9af92d'] = 'E-mail';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_d7e637a6e9ff116de2fa89551240a94d'] = 'Visites';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_ec1ee973b8947391f8f014c76ac7379f'] = 'Commandes valides';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_1ff1b62d08d1195f073c6adac00f1894'] = 'Argent dépensé';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_8b83489bd116cb60e2f348e9c63cd7f6'] = 'Meilleurs clients';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_9a1643c70b51526dd35d546ef8e17b87'] = 'Ajoute une liste de meilleurs clients à tableau de bord des statistiques.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_6602bbeb2956c035fb4cb5e844a4861b'] = 'Guide';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_cb21e843b037359d0fb5b793fccf964f'] = 'Fidéliser les clients';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_c01d21a09f02b8e661114db60a0f60d4'] = 'Garder un client peut être plus rentable que d’en conquérir un nouveau. Il est donc impératif de le fidéliser, c\'est-à-dire de lui donner envie de revenir sur votre boutique.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_197bad7ad08abfd1dc45ab92f96f155d'] = 'Le bouche à oreille est également un moyen d\'avoir de nouveaux clients satisfaits ; car un client mécontent n\'en attirera pas de nouveaux.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_bf0d87b5aa8d331563ee61f2ac82069d'] = 'Pour y parvenir, plusieurs moyens existent :';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_397a5e109a5897ee7d699050cbc93347'] = 'Les opérations ponctuelles : les récompenses marchandes (offres promotionnelles ciblées et personnalisées, cadeaux -produit ou service offert-), les récompenses non marchandes (traitement prioritaire d\'une commande ou d\'un produit), les récompenses pécuniaires (bons d\'achat, de réduction, de remboursement). ';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_4bc24eed56e0ba89fc3ab4e094d18d8a'] = 'Les opérations pérennes : carte de fidélité, points de fidélité. Elles justifient la communication marchand-clients, mais offrent aussi des avantages aux clients (offres privatives, réductions).';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_2f408c42912e3afe23a0e4adcbe34b96'] = 'Ces opérations encouragent vos clients à acheter vos produits et à se rendre sur votre boutique plus régulièrement.';
$_MODULE['<{statsbestcustomers}prestashop>statsbestcustomers_998e4c5c80f27dec552e99dfed34889a'] = 'Export CSV';


return $_MODULE;
