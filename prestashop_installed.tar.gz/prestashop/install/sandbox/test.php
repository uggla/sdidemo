<?php

echo 'ok';
